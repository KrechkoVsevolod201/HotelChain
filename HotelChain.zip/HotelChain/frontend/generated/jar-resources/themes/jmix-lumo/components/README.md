By convention, this directory is used to inject CSS into the shadow DOM of a Vaadin components by creating a style sheet whose name matches the web component HTML element name.

For example, to apply styling to the `vaadin-button` component, create a style sheet called `vaadin-button.css`.