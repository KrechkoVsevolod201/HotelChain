import {applyTheme as _applyTheme} from './theme-HotelChain.generated.js';
export const applyTheme = _applyTheme;
