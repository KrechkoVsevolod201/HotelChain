


if (!document['_vaadintheme_HotelChain_componentCss']) {
  
  document['_vaadintheme_HotelChain_componentCss'] = true;
}

if (import.meta.hot) {
  import.meta.hot.accept((module) => {
    window.location.reload();
  });
}

