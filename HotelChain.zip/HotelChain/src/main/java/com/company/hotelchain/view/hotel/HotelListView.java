package com.company.hotelchain.view.hotel;

import com.company.hotelchain.entity.Hotel;
import com.company.hotelchain.view.main.MainView;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.HasValueAndElement;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;
import io.jmix.core.validation.group.UiCrossFieldChecks;
import io.jmix.flowui.component.UiComponentUtils;
import io.jmix.flowui.component.validation.ValidationErrors;
import io.jmix.flowui.kit.action.ActionPerformedEvent;
import io.jmix.flowui.kit.component.button.JmixButton;
import io.jmix.flowui.model.CollectionContainer;
import io.jmix.flowui.model.DataContext;
import io.jmix.flowui.model.InstanceContainer;
import io.jmix.flowui.model.InstanceLoader;
import io.jmix.flowui.view.*;

@Route(value = "hotels", layout = MainView.class)
@ViewController("Hotel.list")
@ViewDescriptor("hotel-list-view.xml")
@LookupComponent("hotelsDataGrid")
@DialogMode(width = "64em")
public class HotelListView extends StandardListView<Hotel> {

    @ViewComponent
    private DataContext dataContext;

    @ViewComponent
    private CollectionContainer<Hotel> hotelsDc;

    @ViewComponent
    private InstanceContainer<Hotel> hotelDc;

    @ViewComponent
    private InstanceLoader<Hotel> hotelDl;

    @ViewComponent
    private VerticalLayout listLayout;

    @ViewComponent
    private FormLayout form;

    @ViewComponent
    private HorizontalLayout detailActions;

    @Subscribe
    public void onBeforeShow(final BeforeShowEvent event) {
        updateControls(false);
    }

    @Subscribe("hotelsDataGrid.create")
    public void onHotelsDataGridCreate(final ActionPerformedEvent event) {
        dataContext.clear();
        Hotel entity = dataContext.create(Hotel.class);
        hotelDc.setItem(entity);
        updateControls(true);
    }

    @Subscribe("hotelsDataGrid.edit")
    public void onHotelsDataGridEdit(final ActionPerformedEvent event) {
        updateControls(true);
    }

    @Subscribe("saveBtn")
    public void onSaveButtonClick(final ClickEvent<JmixButton> event) {
        Hotel item = hotelDc.getItem();
        ValidationErrors validationErrors = validateView(item);
        if (!validationErrors.isEmpty()) {
            ViewValidation viewValidation = getViewValidation();
            viewValidation.showValidationErrors(validationErrors);
            viewValidation.focusProblemComponent(validationErrors);
            return;
        }
        dataContext.save();
        hotelsDc.replaceItem(item);
        updateControls(false);
    }

    @Subscribe("cancelBtn")
    public void onCancelButtonClick(final ClickEvent<JmixButton> event) {
        dataContext.clear();
        hotelDl.load();
        updateControls(false);
    }

    @Subscribe(id = "hotelsDc", target = Target.DATA_CONTAINER)
    public void onHotelsDcItemChange(final InstanceContainer.ItemChangeEvent<Hotel> event) {
        Hotel entity = event.getItem();
        dataContext.clear();
        if (entity != null) {
            hotelDl.setEntityId(entity.getId());
            hotelDl.load();
        } else {
            hotelDl.setEntityId(null);
            hotelDc.setItem(null);
        }
        updateControls(false);
    }

    protected ValidationErrors validateView(Hotel entity) {
        ViewValidation viewValidation = getViewValidation();
        ValidationErrors validationErrors = viewValidation.validateUiComponents(form);
        if (!validationErrors.isEmpty()) {
            return validationErrors;
        }
        validationErrors.addAll(viewValidation.validateBeanGroup(UiCrossFieldChecks.class, entity));
        return validationErrors;
    }

    private void updateControls(boolean editing) {
        UiComponentUtils.getComponents(form).forEach(component -> {
            if (component instanceof HasValueAndElement<?, ?> field) {
                field.setReadOnly(!editing);
            }
        });

        detailActions.setVisible(editing);
        listLayout.setEnabled(!editing);
    }

    private ViewValidation getViewValidation() {
        return getApplicationContext().getBean(ViewValidation.class);
    }
}