package com.company.hotelchain.view.nightcount;

import com.company.hotelchain.entity.NightCount;
import com.company.hotelchain.view.main.MainView;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.HasValueAndElement;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;
import io.jmix.core.validation.group.UiCrossFieldChecks;
import io.jmix.flowui.component.UiComponentUtils;
import io.jmix.flowui.component.validation.ValidationErrors;
import io.jmix.flowui.kit.component.button.JmixButton;
import io.jmix.flowui.model.CollectionContainer;
import io.jmix.flowui.model.DataContext;
import io.jmix.flowui.model.InstanceContainer;
import io.jmix.flowui.model.InstanceLoader;
import io.jmix.flowui.view.*;

@Route(value = "nightCounts", layout = MainView.class)
@ViewController("NightCount.list")
@ViewDescriptor("night-count-list-view.xml")
@LookupComponent("nightCountsDataGrid")
@DialogMode(width = "64em")
public class NightCountListView extends StandardListView<NightCount> {

    @ViewComponent
    private DataContext dataContext;

    @ViewComponent
    private CollectionContainer<NightCount> nightCountsDc;

    @ViewComponent
    private InstanceContainer<NightCount> nightCountDc;

    @ViewComponent
    private InstanceLoader<NightCount> nightCountDl;

    @ViewComponent
    private VerticalLayout listLayout;

    @ViewComponent
    private FormLayout form;

    @ViewComponent
    private HorizontalLayout detailActions;

    @Subscribe
    public void onBeforeShow(final BeforeShowEvent event) {
        updateControls(false);
    }

    @Subscribe("saveBtn")
    public void onSaveButtonClick(final ClickEvent<JmixButton> event) {
        NightCount item = nightCountDc.getItem();
        ValidationErrors validationErrors = validateView(item);
        if (!validationErrors.isEmpty()) {
            ViewValidation viewValidation = getViewValidation();
            viewValidation.showValidationErrors(validationErrors);
            viewValidation.focusProblemComponent(validationErrors);
            return;
        }
        dataContext.save();
        nightCountsDc.replaceItem(item);
        updateControls(false);
    }

    @Subscribe("cancelBtn")
    public void onCancelButtonClick(final ClickEvent<JmixButton> event) {
        dataContext.clear();
        nightCountDl.load();
        updateControls(false);
    }

    @Subscribe(id = "nightCountsDc", target = Target.DATA_CONTAINER)
    public void onNightCountsDcItemChange(final InstanceContainer.ItemChangeEvent<NightCount> event) {
        NightCount entity = event.getItem();
        dataContext.clear();
        if (entity != null) {
            nightCountDl.setEntityId(entity.getId());
            nightCountDl.load();
        } else {
            nightCountDl.setEntityId(null);
            nightCountDc.setItem(null);
        }
        updateControls(false);
    }

    protected ValidationErrors validateView(NightCount entity) {
        ViewValidation viewValidation = getViewValidation();
        ValidationErrors validationErrors = viewValidation.validateUiComponents(form);
        if (!validationErrors.isEmpty()) {
            return validationErrors;
        }
        validationErrors.addAll(viewValidation.validateBeanGroup(UiCrossFieldChecks.class, entity));
        return validationErrors;
    }

    private void updateControls(boolean editing) {
        UiComponentUtils.getComponents(form).forEach(component -> {
            if (component instanceof HasValueAndElement<?, ?> field) {
                field.setReadOnly(!editing);
            }
        });

        detailActions.setVisible(editing);
        listLayout.setEnabled(!editing);
    }

    private ViewValidation getViewValidation() {
        return getApplicationContext().getBean(ViewValidation.class);
    }
}