package com.company.hotelchain.entity;

import io.jmix.core.metamodel.datatype.EnumClass;

import org.springframework.lang.Nullable;


public enum Type implements EnumClass<String> {

    ECONOMY("ECONOMY"),
    STANDARD("STANDARD"),
    LUXURY("LUXURY");

    private final String id;

    Type(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static Type fromId(String id) {
        for (Type at : Type.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}