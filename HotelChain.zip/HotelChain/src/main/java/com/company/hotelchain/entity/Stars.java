package com.company.hotelchain.entity;

import io.jmix.core.metamodel.datatype.EnumClass;

import org.springframework.lang.Nullable;


public enum Stars implements EnumClass<String> {

    ONE("One"),
    TWO("Two"),
    THREE("Three"),
    FOUR("Four"),
    FIVE("Five");

    private final String id;

    Stars(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static Stars fromId(String id) {
        for (Stars at : Stars.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}