package com.company.hotelchain.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import jakarta.persistence.*;

import java.math.BigDecimal;
import java.util.UUID;

@JmixEntity
@Table(name = "NIGHT_COUNT", indexes = {
        @Index(name = "IDX_NIGHT_COUNT_BOOKING", columnList = "BOOKING_ID"),
        @Index(name = "IDX_NIGHT_COUNT_ROOM", columnList = "ROOM_ID")
})
@Entity
public class NightCount {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "BOOKING_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Booking booking;

    @JoinColumn(name = "ROOM_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Room room;

    @Column(name = "NIGHTS_COUNT")
    private Integer nightsCount;

    @Column(name = "TOTAL_COST", precision = 19, scale = 2)
    private BigDecimal totalCost;

    public void setTotalCost(BigDecimal totalCost) {
        this.totalCost = totalCost;
    }

    public BigDecimal getTotalCost() {
        return totalCost;
    }

    public Integer getNightsCount() {
        return nightsCount;
    }

    public void setNightsCount(Integer nightsCount) {
        this.nightsCount = nightsCount;
    }

    public Room getRoom() {
        return room;
    }

    public void setRoom(Room room) {
        this.room = room;
    }

    public Booking getBooking() {
        return booking;
    }

    public void setBooking(Booking booking) {
        this.booking = booking;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}