package com.company.hotelchain.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import jakarta.persistence.*;

import java.math.BigDecimal;
import java.util.UUID;

@JmixEntity
@Table(name = "ROOM", indexes = {
        @Index(name = "IDX_ROOM_HOTEL", columnList = "HOTEL_ID")
})
@Entity
public class Room {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "ROOM_NUMBER")
    private String roomNumber;

    @Column(name = "TYPE_")
    private String type;

    @Column(name = "PRICE_PER_NIGHT", precision = 19, scale = 2)
    private BigDecimal pricePerNight;

    @Column(name = "STATUS")
    private String status;

    @JoinColumn(name = "HOTEL_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Hotel hotel;

    public Hotel getHotel() {
        return hotel;
    }

    public void setHotel(Hotel hotel) {
        this.hotel = hotel;
    }

    public Status getStatus() {
        return status == null ? null : Status.fromId(status);
    }

    public void setStatus(Status status) {
        this.status = status == null ? null : status.getId();
    }

    public BigDecimal getPricePerNight() {
        return pricePerNight;
    }

    public void setPricePerNight(BigDecimal pricePerNight) {
        this.pricePerNight = pricePerNight;
    }

    public Type getType() {
        return type == null ? null : Type.fromId(type);
    }

    public void setType(Type type) {
        this.type = type == null ? null : type.getId();
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}