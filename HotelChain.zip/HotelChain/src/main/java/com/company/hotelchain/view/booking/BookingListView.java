package com.company.hotelchain.view.booking;

import com.company.hotelchain.entity.Booking;
import com.company.hotelchain.view.main.MainView;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.HasValueAndElement;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;
import io.jmix.core.validation.group.UiCrossFieldChecks;
import io.jmix.flowui.component.UiComponentUtils;
import io.jmix.flowui.component.validation.ValidationErrors;
import io.jmix.flowui.kit.action.ActionPerformedEvent;
import io.jmix.flowui.kit.component.button.JmixButton;
import io.jmix.flowui.model.CollectionContainer;
import io.jmix.flowui.model.DataContext;
import io.jmix.flowui.model.InstanceContainer;
import io.jmix.flowui.model.InstanceLoader;
import io.jmix.flowui.view.*;

@Route(value = "bookings", layout = MainView.class)
@ViewController("Booking.list")
@ViewDescriptor("booking-list-view.xml")
@LookupComponent("bookingsDataGrid")
@DialogMode(width = "64em")
public class BookingListView extends StandardListView<Booking> {

    @ViewComponent
    private DataContext dataContext;

    @ViewComponent
    private CollectionContainer<Booking> bookingsDc;

    @ViewComponent
    private InstanceContainer<Booking> bookingDc;

    @ViewComponent
    private InstanceLoader<Booking> bookingDl;

    @ViewComponent
    private VerticalLayout listLayout;

    @ViewComponent
    private FormLayout form;

    @ViewComponent
    private HorizontalLayout detailActions;

    @Subscribe
    public void onBeforeShow(final BeforeShowEvent event) {
        updateControls(false);
    }

    @Subscribe("bookingsDataGrid.create")
    public void onBookingsDataGridCreate(final ActionPerformedEvent event) {
        dataContext.clear();
        Booking entity = dataContext.create(Booking.class);
        bookingDc.setItem(entity);
        updateControls(true);
    }

    @Subscribe("bookingsDataGrid.edit")
    public void onBookingsDataGridEdit(final ActionPerformedEvent event) {
        updateControls(true);
    }

    @Subscribe("saveBtn")
    public void onSaveButtonClick(final ClickEvent<JmixButton> event) {
        Booking item = bookingDc.getItem();
        ValidationErrors validationErrors = validateView(item);
        if (!validationErrors.isEmpty()) {
            ViewValidation viewValidation = getViewValidation();
            viewValidation.showValidationErrors(validationErrors);
            viewValidation.focusProblemComponent(validationErrors);
            return;
        }
        dataContext.save();
        bookingsDc.replaceItem(item);
        updateControls(false);
    }

    @Subscribe("cancelBtn")
    public void onCancelButtonClick(final ClickEvent<JmixButton> event) {
        dataContext.clear();
        bookingDl.load();
        updateControls(false);
    }

    @Subscribe(id = "bookingsDc", target = Target.DATA_CONTAINER)
    public void onBookingsDcItemChange(final InstanceContainer.ItemChangeEvent<Booking> event) {
        Booking entity = event.getItem();
        dataContext.clear();
        if (entity != null) {
            bookingDl.setEntityId(entity.getId());
            bookingDl.load();
        } else {
            bookingDl.setEntityId(null);
            bookingDc.setItem(null);
        }
        updateControls(false);
    }

    protected ValidationErrors validateView(Booking entity) {
        ViewValidation viewValidation = getViewValidation();
        ValidationErrors validationErrors = viewValidation.validateUiComponents(form);
        if (!validationErrors.isEmpty()) {
            return validationErrors;
        }
        validationErrors.addAll(viewValidation.validateBeanGroup(UiCrossFieldChecks.class, entity));
        return validationErrors;
    }

    private void updateControls(boolean editing) {
        UiComponentUtils.getComponents(form).forEach(component -> {
            if (component instanceof HasValueAndElement<?, ?> field) {
                field.setReadOnly(!editing);
            }
        });

        detailActions.setVisible(editing);
        listLayout.setEnabled(!editing);
    }

    private ViewValidation getViewValidation() {
        return getApplicationContext().getBean(ViewValidation.class);
    }
}