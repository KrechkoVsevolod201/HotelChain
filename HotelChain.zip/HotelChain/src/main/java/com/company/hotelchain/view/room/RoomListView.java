package com.company.hotelchain.view.room;

import com.company.hotelchain.entity.Room;
import com.company.hotelchain.view.main.MainView;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.HasValueAndElement;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;
import io.jmix.core.validation.group.UiCrossFieldChecks;
import io.jmix.flowui.component.UiComponentUtils;
import io.jmix.flowui.component.validation.ValidationErrors;
import io.jmix.flowui.kit.action.ActionPerformedEvent;
import io.jmix.flowui.kit.component.button.JmixButton;
import io.jmix.flowui.model.CollectionContainer;
import io.jmix.flowui.model.DataContext;
import io.jmix.flowui.model.InstanceContainer;
import io.jmix.flowui.model.InstanceLoader;
import io.jmix.flowui.view.*;

@Route(value = "rooms", layout = MainView.class)
@ViewController("Room.list")
@ViewDescriptor("room-list-view.xml")
@LookupComponent("roomsDataGrid")
@DialogMode(width = "64em")
public class RoomListView extends StandardListView<Room> {

    @ViewComponent
    private DataContext dataContext;

    @ViewComponent
    private CollectionContainer<Room> roomsDc;

    @ViewComponent
    private InstanceContainer<Room> roomDc;

    @ViewComponent
    private InstanceLoader<Room> roomDl;

    @ViewComponent
    private VerticalLayout listLayout;

    @ViewComponent
    private FormLayout form;

    @ViewComponent
    private HorizontalLayout detailActions;

    @Subscribe
    public void onBeforeShow(final BeforeShowEvent event) {
        updateControls(false);
    }

    @Subscribe("roomsDataGrid.create")
    public void onRoomsDataGridCreate(final ActionPerformedEvent event) {
        dataContext.clear();
        Room entity = dataContext.create(Room.class);
        roomDc.setItem(entity);
        updateControls(true);
    }

    @Subscribe("roomsDataGrid.edit")
    public void onRoomsDataGridEdit(final ActionPerformedEvent event) {
        updateControls(true);
    }

    @Subscribe("saveBtn")
    public void onSaveButtonClick(final ClickEvent<JmixButton> event) {
        Room item = roomDc.getItem();
        ValidationErrors validationErrors = validateView(item);
        if (!validationErrors.isEmpty()) {
            ViewValidation viewValidation = getViewValidation();
            viewValidation.showValidationErrors(validationErrors);
            viewValidation.focusProblemComponent(validationErrors);
            return;
        }
        dataContext.save();
        roomsDc.replaceItem(item);
        updateControls(false);
    }

    @Subscribe("cancelBtn")
    public void onCancelButtonClick(final ClickEvent<JmixButton> event) {
        dataContext.clear();
        roomDl.load();
        updateControls(false);
    }

    @Subscribe(id = "roomsDc", target = Target.DATA_CONTAINER)
    public void onRoomsDcItemChange(final InstanceContainer.ItemChangeEvent<Room> event) {
        Room entity = event.getItem();
        dataContext.clear();
        if (entity != null) {
            roomDl.setEntityId(entity.getId());
            roomDl.load();
        } else {
            roomDl.setEntityId(null);
            roomDc.setItem(null);
        }
        updateControls(false);
    }

    protected ValidationErrors validateView(Room entity) {
        ViewValidation viewValidation = getViewValidation();
        ValidationErrors validationErrors = viewValidation.validateUiComponents(form);
        if (!validationErrors.isEmpty()) {
            return validationErrors;
        }
        validationErrors.addAll(viewValidation.validateBeanGroup(UiCrossFieldChecks.class, entity));
        return validationErrors;
    }

    private void updateControls(boolean editing) {
        UiComponentUtils.getComponents(form).forEach(component -> {
            if (component instanceof HasValueAndElement<?, ?> field) {
                field.setReadOnly(!editing);
            }
        });

        detailActions.setVisible(editing);
        listLayout.setEnabled(!editing);
    }

    private ViewValidation getViewValidation() {
        return getApplicationContext().getBean(ViewValidation.class);
    }
}